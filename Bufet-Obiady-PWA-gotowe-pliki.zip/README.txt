BUFET – OBIADY
Pliki PWA gotowe do wgrania na GitHub.
Po wgraniu uzupełnimy w index.html Project URL i Publishable key z Supabase.
NIE podawaj hasła Supabase ani secret/service-role key.
